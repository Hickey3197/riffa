Requires OpenCV 2.4+ and RIFFA 2.0+. After both are installed, simply run:

	./build.sh

Then you can execute the application by running:

	./framecap <fpga_id>

Replace <fpga_id> with the RIFFA 2.0 FPGA id that has the convolution design.
